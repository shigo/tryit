<?php

return [
    'adminEmail' => 'akin@olusegun.com.ng',
    'senderEmail' => 'noreply@olusegun.com.ng',
    'senderName' => 'TryIT Traning mailer',
];
